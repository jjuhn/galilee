#!c:\users\ps413\desktop\projects\galileechurch\virtual_website\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
